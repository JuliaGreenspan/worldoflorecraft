# Lore Compendium (from Notion API)


---

# Aeodira Thunderseeker
_Source DB: Characters_

# Aeodira Thunderseeker

---

# Aila
_Source DB: Characters_

# Aila

---

# Aimer
_Source DB: Characters_

# Aimer

---

# A’thian
_Source DB: Characters_

# A’thian

---

# Baron Longshore
_Source DB: Characters_

# Baron Longshore

---

# Bom’bay
_Source DB: Characters_

# Bom’bay

---

# Bwonsamdi
_Source DB: Characters_

# Bwonsamdi

---

# Captain Brightsun
_Source DB: Characters_

# Captain Brightsun

---

# Cinder
_Source DB: Characters_

# Cinder

---

# Cu’ul
_Source DB: Characters_

# Cu’ul

---

# Dambala
_Source DB: Characters_

# Dambala

---

# Drek
_Source DB: Characters_

# Drek

---

# Dura
_Source DB: Characters_

# Dura

---

# Elune
_Source DB: Characters_

# Elune

---

# Farendin Manaflame
_Source DB: Characters_

# Farendin Manaflame

---

# Freyis
_Source DB: Characters_

# Freyis

---

# Gadrin
_Source DB: Characters_

# Gadrin

---

# Gazlowe
_Source DB: Characters_

# Gazlowe

---

# Gazz’uz Voidrender
_Source DB: Characters_

# Gazz’uz Voidrender

---

# Gilthares Firebough
_Source DB: Characters_

# Gilthares Firebough

---

# Godan Runetwist
_Source DB: Characters_

# Godan Runetwist

---

# Harkzog
_Source DB: Characters_

# Harkzog

---

# Igor
_Source DB: Characters_

# Igor

---

# Jazzick
_Source DB: Characters_

# Jazzick

---

# Jes’rimon
_Source DB: Characters_

# Jes’rimon

---

# Jojo
_Source DB: Characters_

# Jojo

---

# Kanyi
_Source DB: Characters_

# Kanyi

---

# Kardis Dreamseeker
_Source DB: Characters_

# Kardis Dreamseeker

---

# Kartosh Soulflame
_Source DB: Characters_

# Kartosh Soulflame

---

# Keeper Ordanus
_Source DB: Characters_

# Keeper Ordanus

---

# Kor’ghan
_Source DB: Characters_

# Kor’ghan

---

# Lor’themar Theron
_Source DB: Characters_

# Lor’themar Theron

---

# Lukou
_Source DB: Characters_

# Lukou

---

# Madam Maram
_Source DB: Characters_

# Madam Maram

---

# Magar Irontusk
_Source DB: Characters_

# Magar Irontusk

---

# Marcog
_Source DB: Characters_

# Marcog

---

# Mi’zae
_Source DB: Characters_

# Mi’zae

---

# Molla
_Source DB: Characters_

# Molla

---

# Mother Norn’sa
_Source DB: Characters_

# Mother Norn’sa

---

# Mozo’re
_Source DB: Characters_

# Mozo’re

---

# Mueh’zala
_Source DB: Characters_

# Mueh’zala

---

# Neeru Fireblade
_Source DB: Characters_

# Neeru Fireblade

---

# Nekros Clantaker
_Source DB: Characters_

# Nekros Clantaker

---

# Nethraza Doomrend
_Source DB: Characters_

# Nethraza Doomrend

---

# Rasa
_Source DB: Characters_

# Rasa

---

# Retick Fiztorque
_Source DB: Characters_

# Retick Fiztorque

---

# Sam’gha
_Source DB: Characters_

# Sam’gha

---

# Satashia Manaflame
_Source DB: Characters_

# Satashia Manaflame

---

# Shadra
_Source DB: Characters_

# Shadra

---

# Shango
_Source DB: Characters_

# Shango

---

# Sugorim
_Source DB: Characters_

# Sugorim

---

# Thrall
_Source DB: Characters_

# Thrall

---

# Urkar
_Source DB: Characters_

# Urkar

---

# Uto
_Source DB: Characters_

# Uto

---

# Vashi
_Source DB: Characters_

# Vashi

---

# Vinebeard
_Source DB: Characters_

# Vinebeard

---

# Volza
_Source DB: Characters_

# Volza

---

# Vol’jin
_Source DB: Characters_

# Vol’jin

---

# Watcher Daru
_Source DB: Characters_

# Watcher Daru

---

# Watcher Voone
_Source DB: Characters_

# Watcher Voone

---

# Whuut
_Source DB: Characters_

# Whuut

---

# Wylie
_Source DB: Characters_

# Wylie

---

# Yelmak
_Source DB: Characters_

# Yelmak

---

# Zalazane
_Source DB: Characters_

# Zalazane

---

# Party Goals Tracker
_Source DB: Party Goals_

# Party Goals Tracker
**Last Updated:** 10/27/2025
**Latest Session:** Session 64
**Arc: ** The Emerald Dream
## **🌀 Summary of Recent Events (Sessions 63–64)**
The Gaytekeepërs continued their northward journey through Ashenvale, following the guidance of Lieutenant Aeodira Thunderseeker toward Raynewood Retreat. After resting along the Fal’Farren River—the contested border between the Horde and the Alliance—the group observed the growing signs of military buildup and political tension between Horde factions. Tauren, Orcs, and Trolls stand united under a blood oath, while the Forsaken and Blood Elves remain uneasy allies.
Along the forest path, the party encountered Vinebeard, an ancient treant who watches over the woods. He confirmed that the darkness corrupting the forest—the same affliction tied to the Emerald Dream—had spread deep into the roots, gnawing at his mind with whispering voices. He did not know its source but warned of its growing reach.
Upon reaching the outskirts of Raynewood, the group met Watcher Daru, who directed them to Keeper Ordanus’ tower. There, they encountered Freyis, a dryad, and were offered lodging for the night before speaking with Ordanus in the morning. The Keeper was overheard debating with his sister, who urged him to remain hidden for his own safety. The session closed with the group preparing to consult Ordanus regarding the corruption—believed to be connected to the Emerald Nightmare.
## **Active Objectives:**
- Investigate and contain the corruption of the Emerald Dream.
  - Now confirmed by Vinebeard to be spreading beneath Ashenvale’s forests.
  - Keeper Ordanus may have insight into its nature or connection to the Nightmare.
- Meet with Keeper Ordanus at Raynewood Retreat.
  - The group has reached Raynewood and is awaiting audience with the Keeper.
  - His sister and fellow dryads appear to be protecting him from an unspecified danger.
- Escort Alyrin safely to the druids of Raynewood Retreat.
  - The group continues to travel cautiously due to Alyrin’s fragile condition following her resurrection.
- Monitor Horde and Alliance movements near the Fal’Farren River.
  - The river marks the warfront’s edge; Zoram’gar Outpost seeks to flank Alliance forces.
  - Potential future conflict may hinder travel or affect Cenarion neutrality.
- Support Ga’an’s spiritual trials.
  - Ga’an’s faith in Bwonsamdi continues to evolve, strengthened by his reflections on mortality and resurrection.
- Unravel the mystery of the Emerald Nightmare.
  - Newly identified as the likely source of the spreading corruption.
  - Connection to the Dream and the Old Gods remains uncertain.
## **Completed Objectives:**
- Reached Raynewood Retreat under Lieutenant Aeodira’s guidance.
- Gained confirmation from Vinebeard regarding the depth of the corruption.
- Established peaceful relations with the Raynewood dryads.
## **Next Planned Destination:**
Raynewood Retreat – Audience with Keeper Ordanus to discuss the Emerald Nightmare and the forest’s corruption.
## **Relevant NPCs:**
- Vinebeard – Ancient treant guardian of the forest; aware of the corruption’s reach.
- Watcher Daru – Night Elf watchman at Raynewood’s gates.
- Freyis – Dryad attendant to Keeper Ordanus; offered lodging to the party.
- Keeper Ordanus – Druidic leader of Raynewood Retreat; suspected to be in hiding.
- Lieutenant Aeodira Thunderseeker – Night Elf escort and intermediary between the party and Cenarion Circle.
- Bwonsamdi – Loa of Death; Ga’an’s patron.
- Elune – Goddess of the Moon; restored Alyrin to life.

---

# Session #10
_Source DB: Session Notes_

# Session #10
# Full Notes
- Shopping episode!!!
- Backpack store <3
- Isilee tries to rob a component store for Adelaide. The rug and armor come to life and she nearly dies from their pursuit

---

# Session #11
_Source DB: Session Notes_

# Session #11
# Full Notes
- The team returns to the Broken Tusk Tavern to find a team of guards and their Worgs investigating around the area (in pursuit of the thief who broke into the component shop, aka Isi)
- The party coats Isilee in onions to disguise her smell while Lu'va is made to smell like Isilee and sent off the other direction to lead the Worgs away.
- The party travels to the Darkfire Enclave to discuss the events with Neeru and get the Eradun missives translated. Neeru recognizes the insignia of Taragamon the Hungerer, a great Fel Guard of the Burning Legion. This could mean another demon invasion of Azeroth. 
- Neeru explains that the first warlocks were shaman, and that Fel drains life-force, leaving only mummified corpses
- The necklaces worn by the warlocks are called Searing Collars, which only work on Orcs but can amplify their Fel casting.
- Neeru translates the missives (which are still in code) for the party and says he will pay them for each searing collar they find
- After leaving Darkfire Enclave, the party are seen exchanging large amounts of money in an alley and are later ambushed (oops)
- Adelaide finds drugs :)
- The party speak to Jes'rimon again and learn of the Searing Blade, a sect of the Burning Blade, who have taken up residence in Ragefire Chasm.
- Jes'rimon has obtained a key for decoding the missive and discovers that it is a letter addressed to Gazz'uz. The letter details a recruitment plan for targetting orc shaman and low-ranking military recruits. Skull rock, where the party fought Gazz'uz, was only one of multiple bases for gauging interest (the uninterested were sacrificed for rituals). The Searing Blade is planning to open multiple portals around Orgrimmar in the shape of a crescent moon and need more support to do so
- Jes'rimon tells the party that due to the North Watch incursion on Duratar, the Shattered Hand's resources are spread too thin to investigate this threat. He asks that they investigate on his behalf, and do what they can to clear out Ragefire. He will award them 10 GP/cultist
- The group ask for potions and Jes'rimon says that while he can't give them any for free, Yelmak will give a discount. (we forget this immediately and do not buy potions before going into Ragefire)

---

# Session #12
_Source DB: Session Notes_

# Session #12
# Full Notes
- Shopping episode part 2
- Juniper purchases the Moon-touched dagger and Alyrin buys the Robe of Useful Items from Marem's Magnificent Magical Wares
- Isilee buys many many squiggle daggers
- Jes'rimon leaves the party a note saying "eyes always watching, be careful"

---

# Session #13
_Source DB: Session Notes_

# Session #13
# Full Notes
- The group fights their first group of orcs at the beginning of the path to Ragefire Chasm
- Pushing further in (and after a long rest), the party fight another camp and find a hidden room behind an illusionary wall
- Inside the hidden room, there is a dead human in cloth robes with a golden anchor crest. The party puts it together that this man is a Kul'Tiran from North Watch (not to be confused with Death Watch).
- They find a blink back belt for Isi!

---

# Session #14
_Source DB: Session Notes_

# Session #14
# Full Notes
- Pushing further towards Ragefire, the group begin to notice holes in the cave walls which seem to be dug out. There are claw marks in and around these holes, but Lu'va's investigation does not reveal much.
- The party find themselves at a shear cliff face, with a frayed rope descending down into the darkness. They tie together their own ropes to descend down and Alyrin goes first, making a commotion by shouting to the party
- Trogs emerge from the holes and begin to attack. Alyrin falls 100 ft and is knocked unconscious. Ga'an descends to try and rescue her but is also knocked off the rope and falls to the ground unconscious. He fails his death saves and dies, yikes
- The noise is loud enough to summon an Earth Elemental which first attacks the trogs, allowing Isilee to safely descend and heal Alyrin.
- Ga'an is reanimated, seemingly by his shadow. We don't have time to unpack all of that...
- Adelaide and Juniper make it down safely, in time to help fight the Earth Elemental
- Ga'an now has black markings and a tattoo of a skull on his chest

---

# Session #15
_Source DB: Session Notes_

# Session #15
# Full Notes
- Ga'an is noticeably more grey, but is evasive when questioned about what happened. He only clarifies that troll magic comes from the Loa
- After a few more skirmishes, the party make it to a room with stone that its worked and smooth, with a carved hand indent and crude runic symbols. The text above it reads "No victory without suffering"
- Isilee pours a vial of Orc blood she had collected onto the handprint causing a pulse to reverberate through the chamber, revealing a doorway
- The party pass a large stone statue and find an extinguished campfire and a hut with a collapsed roof. Ga'an begins to summon a shadow, which makes his tattoos glow
- The party are ambushed while investigating the collapsed hut and are fireballed twice, but ultimately win the fight
In the aftermath, they find 10+ bound bodies, one of which has a necklace with the inscription "Dura, my love". 
- Investigating the statue, it shows a bipedal humanoid with cloven hooves, an elongated head with tentacles and sharp, plate-like growth. The figure has horns which curl inwards and elf-like ears. At the foot of the statue, there is a shrine of bone. The inscription on the statue's base reads "Kil'Jaedan, The Great One". The party know him as the progenitor of the Orc race, lord of flame, and "the deceiver".
- The party overhear guards talking about Bazzalan, referring to him as a Satyr, and saying that he wants the portal open

---

# Session #16
_Source DB: Session Notes_

# Session #16
# Full Notes
- The party gets their shit rocked by a Doom Guard. Ouch

---

# Session #17
_Source DB: Session Notes_

# Session #17
# Full Notes
- Adelaide wakes up on the wrong side of bed and while on watch, overhears a conversation of two guards discussing checking on Troch's landing to see if initiates are needed. They express their frustration about Sozar, who gets to just "sit on the cliff and watch"
- The party push forward when everyone is awake and Ga'an summons 2 shadows.
- 2 encounters go very well, the 3rd is rough
- Ga'an shouts "Your souls for Bwonsamdi" which is a little concerning
- They find a prisoner who says his name is Uto. Yay!!
- Adelaide would like to leave Ragefire now, thank you very much

---

# Session #18
_Source DB: Session Notes_

# Session #18
# Full Notes
- The session began with Adelaide arguing for the group to return to Orgrimmar now that Uto had been found.
- The party persuades her to stay and push onwards because they'll all totally be super fine
- Conversing with the Orc prisoners reveals that the names Taragamon and Jergosh have come up in discussions between guards-- they are probably running this operation
Uto mentions that he is a veteran of the First War. The party lies that they've moved into his house while he was gone
- Ga'an continues to be evasive about his new powers and everything that has occurred since his alleged death. When asked about Bwonsamdi, he explains that he is the loa of the dead, and therefore is a good deity to have the favor of given the killing and death surrounding the party
- The party brainstorm codewords for battle strategies, which are: Despacito - bladesong; Hasslehoff - buff; Scatter - scatter; Merry-go-round - everyone go into Melee
- The party heads deeper into Ragefire and find mummified corpses on a bridge. They identify one body, to be Urkar Firefist, the young shaman that Kardris Dreamseeker told them had disappeared. Clutched in his fist, they find his totem
- A booming voice echoes around the chasm - Taragamon the Hungerer: “Mighty heroes of the Horde, welcome to Ragefire Chasm! I've been expecting you.”
- The party rushes forward to confront Taragamon, and Adelaide is almost immediately yeeted into the lava, where she misses the insta-death threshold by one point of damage
- The party miraculously prevails without any deaths today, yay
Pouring lava descends on the party, who all start to run before Isilee identifies that it is an illusion and confronts the hiding cultist who conjured it
- The cultist states that Bazzalan will get here soon and Taragamon was just a figurehead meant to distract them. Isi kills him after acquiring this information.
- The party find an "office" further into the cave system with a grimoire on the table initialed "N.F.". They can hear cultists chanting not too far away
- Adelaide notices that Taragamon's blade, which glows in the presence of Fel magic, glows a bit brighter when near Isilee. She asks Isilee to cast a cantrip for her and remarks that it's interesting but won't clarify further.
- The party double back to the last camp they cleared, dump the orc bodies in lava, and set up for a long rest

---

# Session #19
_Source DB: Session Notes_

# Session #19
# Full Notes
- Isilee tries very hard to make friends with Ga'an and Adelaide. Neither conversation goes particularly well, but Ga'an opens up slightly about who his parents were and why the Echo Isles are important to him. Adelaide mentions that she was once close to someone named Mina, but they haven't spoken in a very long time.
- The GayteKeepërs inspects a grimoire initialed "N.F": it is an extensive journal primarily written in Eradun. It seems to be a research journal
- The party encounter Bazzalan the Satyr and stop a group of warlocks from summoning another Fel Guard just in the nick of time. Many souveniers are taken from Bazzalan's corpse. Some are consumed.
- Isilee mentions missing her fiancé Pietro, and their murder-cuddles
- The GayteKeepërs face off against Jergosh, who has been running the operation. He real dead now
- The party finds Neeru's monocle and Jergosh's research book

---

# Session #1a
_Source DB: Session Notes_

# Session #1a
# Full Notes
• Isilee meets Captain Brightsun at a tavern and receives a quest to rescue his cousin, Giltheras, from the Southsea Freebooters.
• Alyrin joins the conversation and volunteers to help in exchange for passage north. Isilee insists she works alone, but Alyrin follows her anyway.
• Isilee pulls off her first heist—*cue the Mission: Impossible theme*—successfully stealing a map and a potion.
• Isilee and Alyrin infiltrate the pirate camp. Things go smoothly… until they’re discovered and promptly knocked out.

---

# Session #1b
_Source DB: Session Notes_

# Session #1b
# Full Notes
- Adelaide is staying at the Broken Keel Tavern in Ratchet and overhears a group of Bruisers discussing how the South Sea Freebooters are a threat
- Ga'an walks into the tavern and is immediately kicked out by Wylie after he orders a drink with no money to pay for it
- Adelaide is given information that Gazlowe, the leader of the town, will pay for someone to aid in hunting down bandits
- In search of a job, Adelaide sets off to find Gazlowe's residence, and is trailed by Ga'an.
- Inside of Gazlowe's residence, Adelaide and Ga'an meet Retick Fiztorque, the head of the Bruisers.
- Gazlowe offers Adelaide and Ga'an a bounty of 50 GP for the head of Baron Longshore, leader of the South Sea Freebooters. Gazlowe would also pay an additional 5 GP for the sigil of every pirate slain. He also requested that the team look out for a stolen shipment containing a looking glass.
- Adelaide, Ga'an and Retick set out for the pirate camp. After clearing out several groups of pirates, the team is surrounded and it is revealed that Retick has been working with Longshore all along and has lead the two into a trap.
- Adelaide surrenders while Ga'an is knocked unconscious (setting a precedent), and they are both thrown in a prison cell where Gilthares Firebough, Isilee, and Alyrin are being held.

---

# Session #2
_Source DB: Session Notes_

# Session #2
# Full Notes
- First full session with the entire party playing together (pre-Juniper).
- The group has a *meet-cute*… in a pirate cage. ❤️
- Isilee manages to lockpick her way free, but can’t release the others before chaos breaks loose.
- A major fight ensues as the party battles their way out—without access to any spellcasting foci.

---

# Session #20
_Source DB: Session Notes_

# Session #20
# Full Notes
- Isilee fills Adelaide in on what's happened in Silvermoon since she left: King Anasterian Sunstrider was killed by Prince Arthas Menethil (who also killed his own father, King Terenas Menethil). Prince Kael'thas Sunstrider still lives and is now leader of Silvermoon
- Alyrin uses the spell scroll patch from her robe and gives it to Adelaide. It is a scroll of Detect Thoughts
- Adelaide tries to jump across a pool of lava, with Isilee attempting to catch her. They both fall in. Juniper also falls in trying to help pull them out. Miraculously everyone survives
- The GayteKeepërs find and kill a basilisk on the way out of Ragefire Chasm. Alyrin is turned to stone during the fight but luckily the party find a bag of holding with a petrification antidote
- After a brief Trogg encounter, the party finally find themselves back at the Cleft of Shadows.

---

# Session #21
_Source DB: Session Notes_

# Session #21
# Full Notes
- The GayteKeepërs make their way to Yelmak's Alchemy, where they sell the basilisk parts they harvested and go to meet with Jes'rimon.
- The party is introduced to our brother, our captain, our king, Whuut
- Jes'rimon is surprised to see the party alive (same) and is at first skeptical of their claims that Neeru was collaborating with the Searing Blade. He compares the handwriting of the documents the party found to the translation of the Eradun missive Neeru previously gave the party and does find them to be comparable
- Jes'rimon recognizes several names on the list of "Eyes and Ears in Orgrimmar". One is Kartosh Soulflame, a well-respected Shaman in the Valley of Wisdom. Another familiar name is Nekros Clantaker, a gang leader in the Cleft of Shadows.
- After meeting with Jes'rimon, the party run some quick errands on the way to the Broken Tusk Tavern, where they promptly get hammered on Tauren Kodo Sweat (this drink is chosen in particular in honor of the Tauren Winter Veil festival which occurred while the party was in Ragefire Chasm.
- The party attempt to sleep off their drinks but are attacked in the middle of the night by assassins, who they mostly wipe the floor with (but one gets away >:( )

---

# Session #22
_Source DB: Session Notes_

# Session #22
# Full Notes
- The Gaytekeepërs are woken by a knock on the door of their shared room -- two orc guards who identify themselves as Mojka and Komak.
- The guards report that the intruders from the night before were members of the Clantaker gang. This is concerning as the gang is not typically known to venture far from the Cleft of Shadows, particularly not to the Valley of Strength where the embassy is located.
- The party convinces the guards that they are unfamiliar with the Cleft of Shadows, and that they were likely attacked due to being drunk and having come into money from cashing in on a contract with Yelmak
- The party head downstairs to breakfast. An Orc bumps into Isilee, who looks down to discover a note with the Shattered Hand logo that simply reads "URGENT"
- Juniper casts Pass Without a Trace on the party, who all make their way to Yelmak's Alchemy as stealthily as they can.
The door is locked when they arrive and upon knocking, a voice yells that they're closed. Jes'rimon recognizes the party and tells Yelmak to let them in.
- Yelmak's store is in disarray, appearing to be ransacked, the floor littered with shattered bottles and books fallen from shelves
- Yelmak himself is visibly injured, as is Jes'rimon. Jes'rimon explains that the store was attacked during the night by three orcs who tried to break into Jes'rimon's office. The body of one, dispatched by Jes'rimon, lies on the ground with a gash across his neck. The other two, one male and one female, escaped (but the female was slashed across the eye)

---

# Session #23
_Source DB: Session Notes_

# Session #23
# Full Notes
- A plan emerges: confront Neeru directly, with Jes’rimon providing backup, to gauge his reaction.
- Juniper and Isilee stock up on supplies at the inscription store so Adelaide can make a copy of the grimoire.
- Alyrin dives into arts and crafts—learning to emboss—and it goes flawlessly. Everyone agrees it’s perfect.
- Jes’rimon (repeatedly) reminds the group: we are NOT giving Neeru the copy, just showing him we have it.
- The team heads to the Cleft of Shadows to execute the plan but spots two guards on worgs leaving the cleft—one of them is Harkzog.
- The group hides in an alley while Jes’rimon and Isilee (with pika Lu’va) stake out the Darkfire Enclave tent.
- The tent is shuttered, with two orcs inside. Isilee overhears them discussing that someone attacked Neeru earlier that day. She and Jes return to report back.
- Isilee and Alyrin head back, release pika Lu’va, and use the distraction to investigate. Alyrin charms one of the orcs while Isilee and Lu’va keep them busy.
- They learn that Neeru was attacked by an orc woman with a facial scar, whom he killed; he was only lightly injured. The guards don’t know where Neeru lives. Isilee may or may not have promised to bring him cactus apple bread.
- On their way out, Isilee and Alyrin spot a spy in an alley. They manage to take him down non-lethally and dose him with truth serum.
- The group interrogates him—Alyrin’s finger obsession makes a reappearance—and learns:
- The spy’s name is Marcog, and he works for Nekros.
- No one actually attacked Neeru.
- Neeru summoned Nethraza Doomrend, a laborer in the Drag and Eyes-and-Ears target, then killed her with green fire.
- Neeru operates out of a tunnel off Shadow Swift Underground, and Marcog gives directions.
- Jes’rimon assigns the next task: take out Nekros and Harkzog. (Late-night assassin fun time!)

---

# Session #24
_Source DB: Session Notes_

# Session #24
# Full Notes
- The GayteKeepërs head towards the Shadowswift Brotherhood to find Nekros and hopefully bring him in for questioning
- Upon reaching the alcove where Nekros has made his hideout, Isilee sets off a trap which explodes, knocking Adelaide unconscious
- Pushing further in, another trap is set off (this time a swinging log) which hits Isi.
- Ga'an is investigating a table in the room when he is stabbed from behind and drops unconsious
- A battle ensues wherein the party are able to subdue Nekros (via Ga'an's sleep spell). They tie him up. disarm him, and feed him Isi's truth serum potion
- Nekros is initially reluctant to part with any information, and is unfazed by the removal of his finger during the interrogation
Eventually, the Gaytekeepërs are able to convince him that Thrall will grant mercy and is his best shot at living
- Nekros relents and spills the beans, confirming the attack on Neeru to be a false flag and sharing that their new goal was to clean up lose ends in their network, with the next target being Harkzog. Kartosh was potentially going to be kept alive as he was still useful for bringing in young shaman eager to prove themselves
- Nekros allied with Neeru due to the promise of power with the Burning Legion's return
- Neeru and Nekros were going to meet in the early morning at the Darkfire Enclave to discuss next steps
- The party knock Nekros out one more time and stuff him into an empty barrel so they can carry him through the Cleft of Shadows without suspicion. While searching his hideout, they also find a ledger containing the operations of the Clantakers
- The Gaytekeepërs travel back to Yelmak's Alchemy, dropping the barrel once but otherwise successfully carrying it to their destination. Upon showing their prize to Jes'rimon, they find that Nekros has died during the journey (due to the blood loss from his missing finger)
- The party fill Jes'rimon in on what occurred, and agree that their next course of action should be to stakeout Harkzog and hopefully capture him alive.

---

# Session #25
_Source DB: Session Notes_

# Session #25
# Full Notes
- The GayteKeepërs attempt to travel stealthily to the Valley of Honor to reach the Hall of the Brave where they hope to find and interrogate Harkzog
- The party splits up into two groups to locate Harkzog
Isilee eventually spots Harkzog going into a building and signals through Lu'va for the others to catch up to her
- Ga'an notices multiple sources of deep, heavy, animalistic breathing: Harkzog is currently in the Worg stables, tacking up one of the many Worgs
- Isi is a bit too enthusiastic in her sneak attack and one hit-KOs Harkzog. Luckily, he's only mostly dead and Alyrin is able to bring him back from the brink.
- The party notices that Alryin looks a bit more gray than usual and she is struggling to cast Holy magic
- The Worgs begin to stir and make a commotion, causing the party to quickly flee with Harkzog in tow as a group of guards come around the corner
- The guards are able to track the group with the help of the Worgs, so Adelaide and Isi split off from the group to try and make a diversion
- Adelaide assumes the form of a young troll, telling the guards that her name is "Ba'an" and that she is lost. This doesn't go as well as planned and the two end up fleeing, accumulating several points of exhaustion and finally finding refuge in an engineering shop, careful to avoid the many deadly traps. The guards have much less luck and are nearly killed by a giant metal piston spike, causing them to abandon their chase
- Meanwhile, Ga'an, Alryin, and Juniper have their own shenanigans attempting to find a cart for Harkzog's body, but manage to make it back to Yelmak's Alchemy's...just to realize they've been tracked there by the Worgs
- Jes'rimon is forced to use his status as a member of the Shattered Hand to turn the guards away, compromising the secrecy of his base of operations. He is very, very pissed about this
- An interrogation of Harkzog ensues, where he reveals that he was trying to defect from the Searing Blade as he only joined to help restore the Horde (more specifically, orcs), return to its former glory
- After learning of Nethraza Doomrend's fate, he finally had enough and wanted to leave before Neeru Fireblade or Nekros Clantaker killed him

---

# Session #26
_Source DB: Session Notes_

# Session #26
# Full Notes
- The party split up to run errands, including picking up items ordered from the leatherworker, specifically an intern girl named Kamari, and the jewelcrafters, run by a pair of identical blood elf twins
- The GayteKeepërs confront Neeru, resulting in a fight
Adelaide drops unconscious, and her soul becomes trapped inside of a soul gem
- After defeating Neeru, Alyrin is able to successfully resurrect Adelaide with the help of Isilee and Juniper
- Neeru is escorted by members of the Shattered Hand to Thrall
Back at the tavern, the party recuperates from the difficult encounter. Adelaide reads one of the tomes found in Neeru's office, learning of the history of the Eredar and their pact with Sargeras. Adelaide additionally learns that this brought about the Third War, which culminated in the Battle of Mount Hyjal and the burning of Nordrassil
- Alyrin, distressed by this knowledge, explains that she was born before the Sundering during the Long Vigil. She joined the priestesses of Elune and became a Sentinel, protecting the lands of the Night Elves. She was killed in the Battle of Mount Hyjal and resurrected as a Dark Ranger under Sylvanas Windrunner.
- Adelaide is surprised to learn of Sylvanas' (un)death. Isilee informs her that Lor'themar Theron is the new Ranger General and Lord Regent while Prince Kael'thas Sunstrider travels

---

# Session #27
_Source DB: Session Notes_

# Session #27
# Full Notes
- Isilee, Adelaide, and Juniper run some errands in the Valley of Strength while Alyrin and Ga'an travel to the Valley of Spirits
- Ga'an has a vision quest and is told by Bwonsamdi to travel to First Home, as is the traditional rite of passage for witch doctors. The catch: First Home is part of the Darkspear isles, which were sunk under water by a sea witch when Ga'an was 10 (he's now 17).
- Ga'an also learns the Bwonsamdi was not always a Loa. The original loa of death was Mueh'zala, who liked the tip the scales in favor of life.
The Sandfury Tribe still worship Mueh'zala and make sacrifices to him. Bwonsamdi would like Ga'an to kill their Chief, Ukorz Sanscalp.
- The party reconvenes at the tavern, and Ga'an recounts the events of his vision as well as his plan to find sailors in his hometown to guide him to where Darkspear once was

---

# Session #28
_Source DB: Session Notes_

# Session #28
# Full Notes
- The session begins at the tavern, with Emissary Blackhoof arriving to speak with the GayteKeepërs about the Cenarian Circle
- Blackhoof tells the party of troubling instances of Night Elves not awakening from the Emerald Dream. The druids are unsure of the nature of the issue, especially as their leader, Malfurion Stormrage, has also fallen victim to this.
- Fandral Staghelm has become the interim leader of the Circle in Malfurion's absence. He does not wish for non-druids or undead to enter Moonglade, but Blackhoof gives the Gaytekeepërs a letter requesting that they be given access.
- Moonglade is located near Mount Hyjal, and can be accessed via the Goblin city Everlook
- The party receives a letter from Jes'rimon thanking them for their help, and promising to be in touch shortly about a reward.
- The party makes an overnight trip to visit Rasa and Uto, where they are welcomed with open arms and gifted Uto's old battleaxe. Orcbnb

---

# Session #29
_Source DB: Session Notes_

# Session #29
# Full Notes
- Whuut struggles with colors, which may be why he struggles with making and selling potions.
- Whuut is colorblind.
- Since he’s colorblind, Juniper made him a greyscale flower crown and gave him a delicate forehead kiss.
- Alyrin tells the party of her vision quest where she spoke to and fought her dark reflection
- Alyrin and Isilee went to sleep several hours past Juniper and Adelaide.
- Jes'rimon summons Adelaide to assist the Shattered Hand on a mission. Adelaide follows, and only Juniper and Ga’an saw her leave.

---

# Session #3
_Source DB: Session Notes_

# Session #3
# Full Notes
- The group loot Baron Longshore's body finding coin, a small hand pistol (taken by Adelaide), a healing potion, and a pistol.
- The group decapitates Longshore to bring his head back to Gazlowe.

---

# Session #30
_Source DB: Session Notes_

# Session #30
# Full Notes
- The Gaytekeepers left for the Valley of Wisdom to Thrall’s building, Grommash Hold.
- The corpse of Mannoroth, a demon, is being braced against a giant spike at the entrance of Grommash Hold. A plaque reads: “A testament to the sins of the orcish people, may Grommash’s sacrifice free us of our shackles once and for all.”
- Mannoroth was a Pitlord who enslaved the orcs. Grommash was the first to partake in the gift and the last to finish him off.
- Orc guards line the canyon. Many have black armor with gold detailing, all of which is much more intricate than the armor worn by city guards.
- Several orcs have larger pauldrons and armor with more detailed and decorative armor.
- When the party (minus Adelaide) arrives into the Hold, Kardris Dreamseeker waits for them. The party gives Urcar Firefirst’s totem to Kardris. She thanks them and returns the totem to the Gaytekeepers.
- Eitrigg is Thrall’s advisor. He’s an orc guard with a massive pauldron on one shoulder, likely depicting his rank. He leads the party (minus Adelaide) through hallways until they arrive at a large circular room that has multiple arches and rises to it. There are roughly 12 guards on the edges of the room.
- There are numerous banners hung around the room; one depicts a white wolf face, another, a skull on a red banner. The iconography is detailed and interesting.
- Thrall is a deep emerald green skinned orc with incredibly ornate black and gold armor. He is reading a document when the party arrives; a pike with the head of Neeru Fireblade is at his side.
- Thrall welcomes the party as friends. He’s filled with hope, considering the party to be a representation of the new Horde. He emphasizes this while looking at the elves.
- The party is gifted an orb that will allow Adelaide to find her way back to the party. Ga’an takes the orb.
They then go into the feast, which is filled with breads, smoked meats, and other delicacies.
- Chieftain Vol’jin is a blue troll with traditional tribal paint on his face. He is of the Darkspear trolls. Kardris also enters the room, as does the rest of the elder council.
- Sagorne is a shaman.
- Mokvar and the troll woman seem like lightweights.
- Gotura Fourwinds, a Tauren shaman and ambassador from the Earthen Ring, commented that "the elements are still shy".

---

# Session #31
_Source DB: Session Notes_

# Session #31
# Full Notes
- The GayteKeepërs are still at the lunch. Thrall puts down his turkey leg and says, "what will you all be doing now that we have finished your adventure?"
- Ga'an wants to get to First Home. Another troll tells Thrall it is a sacred place for the dark spear trolls who wish to attune themselves with the loa and prove themselves. A darkspear troll can never truly connect with the loa of their own will without doing so.
- Isilee asks for supplies or suggestions for supplies. He suggests a single potion of water breathing. He also suggests finding others who have expereicne with the isles, and skills like fishing, navigation, etc. Sen’jin Village, of which Ga’an is familiar, is a few days journey to the southern tip of Duratar. The larger group asks when we think we head out, we respond soon, likely in the next day.
- The troll tells Ga’an that he hopes Ga’an understands the importance(?)/task(?) of Ga’an’s passage to first home. He wishes Ga’an the best and impacts some wisdom into Ga’an. The troll we speak with was one of the last trolls to go to the isles prior to the sinking by the seawitch
- The troll asks how much we know about mitt romney. Since we know a bit of him, he explains that romney is a well known loa in the circle. He can tell Ga’an hopes to prove himself and that Ga’an has already been marked by the loa. The most important resource is going to be those that you keep around you, those that you see. The darkspear would not be alive today if we didn’t find friends in the orcs and the tauren. We come from different backgrounds and we rely on each other. Together we are stronger.
- Zalazane was the friend of the troll that we’re talking to. It was only by going together that they got out together. Time also passed different. What was less than a day was actually more than 3 months. Know those you can trust and why. You cannot do it alone.
- He calls Ga’an a fool for wanting to go up against Zelazane. He plays games with your minds, his power rivals or even exceeds that of this trolls father. Zelazane is a trickster. If you wish to even rival his power, Ga’an needs to go to first home and needs to converse with the loa.
- Ga’an makes fun of Juniper for having hooves because apparently it’s hard to swim with hooves.
- Alyrin talks to someone regarding getting to Moonglade, and that she should talk to some druids at the Grove of the Oliver Branch. Alyrin doesn’t know how to get to Moonglade and we didn’t ask the emissary from the Cenarian circle. It borders on the Fel wood, Winterspring and Dark Shore. To get that far north, you have to go pretty far North, which is very difficult, especially in Winter. Saoirse doesn’t think that going north is a good idea, and Alyrin thinks her brother is worth it.
- Thunderbluff is calling for aid given the recent increase in Quilborn raids and the Venture Company. Thrall asks for a moment and then thanks the Gaytekeepers. We offer to help, since the Horde is spread pretty thin. North Watch and the Quilborne, and in Ashara and Ashenvale are spreading resources really thin.
- Alyrin wanted to asks about all the banners in the throne room, with all the weird symbols.
- Thrall responds that the banners are the banners of the orc clans that compose the horde. The banner that we’re looking at, the burning blade, was once a very noble clan within the horde and some of its people are still within the horde. However, after coming to Azeroth, they became more of a cult and branched off to become demon worshippers. Bleeding Hallow, Warsong, Blackrock, Frost wolf, etc. The shattered hand is also one.
- Anyway, Thrall leaves, and we leave to go shopping. Isilee talks us up as we leave. Kardris Dreamseeker tells us to travel safely.
- We end up going to the Grove of the Olive Branch. We meet two tauren there, and Alyrin says we’re going to go because it would be really cool, but we don’t actually know how to get there. The tauren says that that’s an important detail (she’s being sarcastic lmao). The druids usually wild shape to get there. The alternative is to go to Fel Wood, and there lies a very secluded secret tunnel that is often used to bring visitors in. Our best bet is to find and take the tunnel to get there. She doesn’t have a map.
- You’re going to want to go to the very north tip of Fel wood. There’s a village of furbolg that lies to the north in the very northern reaches of Fel Wood. They were once very honorable, but the corruption that has created fel wood has changed and corrupted them, driven them to madness, but they were once protectors of this entryway. At the very northeastern edge, we’ll find the tunnel. The tunnel will lead us to Moonglade. The tunnel is small enough that we would need to walk single file. Its is under the boughs of a great tree. There’s no specific door, it hasn’t been used in a hot minute, so she doesn’t know what we need to get in.
- Our biggest barrier will likely be anyone guarding the tunnel from Fel Wood’s side or Moonglade’s side. The tribe that we are looking for is now known as the Fel Paw. The biggest barrier will be the tribe that stakes claim to that entrance. The tree is ancient. The tree will probably stick out.
- We went to Yelmacks and proceeded to do fast shopping.
- We went to the tavern and purchased food, alcohol, and water. We talk about going to the map store, then we head up to the room. Ga’an meditates.
- In the morning, Juniper purchases several maps, we all buy fanny packs, and then we bounce, with Juniper at the lead. Ga’an and Juniper both do herbalism checks and at the end of the day, everyone works on their own respective hobbies. Juniper casts goodberries in the morning, and passes them out in the evening. She also gives one to Stoga.
- Juniper casts alarm to wake up the party if anyone, excluding Adelaide and Lu'va, cross the boundry.
- We hear some kind of bird-like cry screech in the night, and more voices join in as a chorus. Naturally, we go towards the noise because we are brave and invincible adventurers.
- Juniper casts pass without a trace on the group, including Ga'an's two summoned shadows, Chad and Greg. We’re sneaking off to find the source. The canyon forks in numerous directions and we end up going upper right.
- Alyrin and Ga’an helped guide Juniper. Juniper does not want to hold the hand of Chad or Greg.
- We hear a similar, but louder, noise as we continue on the path. There’s blood on the trail, and Alyrin can hear the sounds of tearing.
- Juniper starts walking mindlessly towards something, down the path. She’s staring distantly, and she’s kind of in a fugue state. There’s a beautiful, melodic sound playing. The shadows can also be charmed, and both Greg and Chad begin following Juniper.
- Ga’an dismisses both Chad and Greg.
- Juniper is walking forward ahead of the group under some kind of spell.
- Isilee, Ga’an, and Alyrin have to run to catch up with her. As they catch up, we see these large creature with large wings, arms, and terrifying beast things. Combat begins. Juniper really wants to be with the birds, but then she snaps out of it. Then, Juniper gets charmed again, while the rest of the party does not. Soairse, Alyrin, Isilee, and Ga’an continue to fight the harpies.
- Juniper has not succeeded on a single saving throw against these harpies.
- Isilee also gets caught by one of the harpies in a different turn.
- Everyone breaks free, thanks to Ga’an, Saoirse, and Alyrin. The harpies are disposed of with some fairly excessive violence. The gang rolls some checks to find some treasures and feathers.

---

# Session #32
_Source DB: Session Notes_

# Session #32
# Full Notes
- The GayteKeepërs arrive in Sen'jin Village after dark, where they are stopped by Watcher Voone. He lets the group pass when he recognizes Ga'an, but informs them that the town is on edge after the previous night's raid. Voone alerts Ga'an that he should check on his family, whose home was hit hard in the attack
- As the party walks to Ga'an's family's hut, Ga'an is stricken by the memory of the raid which took his father and left his mother crippled. Ga'an had hid under the table, paralyzed by fear. His younger brother saved the life of both Ga'an and his mother.
- The orb of teleportation begins to glow as they reach Ga'an's home, and out pops Adelaide
- Isilee gives Adelaide a hug and they quickly catch up on the last 10 days before Ga'an knocks on the door to his family's hut
- Inside, they meet Ga'an's mother, Molla, who is now bound to a makeshift wheelchair. She is delighted to see her son, but still distressed over the condition of Ga'an's brother, Volza, who lost an arm in the attack. He is currently sleeping, but his recovery has been unnaturally slow-- there is belief in the village that the raiders may have begun coating their weapons with something that impedes healing.
- Molla is also concerned by Ga'an's appearance. She initially laughs when he tells her of his communications with Bwonsamdi, but sobers when she realizes it isn't a joke. Molla suggests Ga'an consult with Gadrin about this, warning that Bwonsamdi "does not just give"
- Ga'an quickly introduces the rest of the party to his mother, but quickly ushers them out and leads the group to the Loa's Shrine Inn
- The inn is run by a Troll named Drek, from whom the party rents two rooms for the night.
- The party attempts to get Ga'an to open up, but he is guarded and evasive.
- In the morning, the group encounter Watcher Voone once more in the tavern, and engage him in conversation about Ga'an's quest for First Home. Voone is skeptical of how the party plans to go somewhere that is now under water, but suggests they speak to Vashi, who runs the Sen'jinn shipyard. She is one of the troll sailors who did not leave to enlist in the Horde navy, and can likely assist them in reaching Darkspear.
- Now seeing the village in daylight, The Echo Isles are visible across the water. It is filled with lush palm trees which have begun to claim the large Mayan-esque stone structures on the shore.
- The party return to Ga'an's home. Volza is still sleeping, but Molla is awake and happy to see Ga'an. She is interested in hearing of the party's exploits and tells Ga'an that his father Cu'ul would be proud of him.
- Isilee snoops around the hut and accidently knocks to the floor a case containing two ceremonial necklaces, much to Molla's distress. These were the necklaces that she and Ga'an's father wore to symbolize their marriage, and Ga'an has not seen them since his father was taken.
- Volza finally wakes up and is excited to see his brother. He is in terrible shape, depsite his natural Troll regenerative abilities. He's little more than a child, with his tusks just starting to come in, one at a crooked angle. Volza and Molla both have golden eyes, unlike Ga'an's stark blue.
- An unfortunate comment about Volza's severed limb gets the party more or less kicked out, and Ga'an is given a list of errands to run for his mother. When Ga'an returns from these errands, Gadrin and his assistant Bom'bay are at the hut, speaking to his mother.
- Gadrin is visibly uneasy at Ga'an's appearance, and warns him of the dangers of dealing with Bwonsamdi. Ga'an brushes him and his mother off, insisting that he knows what Bwonsamdi wants from him in return, and is not concerned about doing it.

---

# Session #33
_Source DB: Session Notes_

# Session #33
# Full Notes
- The GayteKeepërs visit Jojo's Mojo and sell the Orb of Time for 500 gold, lying about it possessing Wild Magic capabilities.
- The party travels to the beach to await the return of the fishing ships. In the meantime, Ga'an casts Water-breathing on the group and everyone begins to experiment with swimming and fighting underwater.
  - Wanting to test their abilities, the party swims out to investigate an old shipwreck. They find it filled with crab people (Makrura), and decide to return later when they are more prepared for a fight,
- Swimming back to shore, the party meet the head of the shipyard, Vashi, and her husband A'thian.
  - A'thian remembers the region where the Darkspear Islands once were. He can spare himself and two others to aid in navigating to the islands,
  - They will charge a rate of 15 GP/day for their services, and will need the party to secure a seafaring vessel and crew in Bladefist Bay.
- Darkspear should be roughly six days from Bladefist if the winds are good, and it will take two or three days from Sen'jin Village to reach Bladefist,
  - A'thian agrees to depart the day after tomorrow, setting sail at 6am. He will be joined by Sam'gha and Mi'zae as navigators.

---

# Session #34
_Source DB: Session Notes_

# Session #34
# Full Notes
- The session begins with the party coming to consciousness at the inn and making plans for the day over breakfast.
  - Ga'an, Adelaide, and Alyrin will go to JoJo's
- At JoJo's, team GAA purchases 5 necklaces which will allow them to speak (and therefore cast spells) underwater. They also acquire a +1 bow and +1 shortsword.
- GAA team went to Jojo’s, and bought 5 magic necklaces a bow of +1 and a short sword of +1
- The Gaytekeepërs travel back underwater and decimate the local crab population.

---

# Session #35
_Source DB: Session Notes_

# Session #35
# Full Notes
- Upon entering the ship, the Gaytekeepërs find several decaying bodies, some of which appear to have been Forsaken.
  - OOC, we realize these are the bodies of our one shot characters
  - The party loots the ships remains, uncovering a lute engraved with, "*To my biggest fan, Este. Love, Saylor Twift*". They also uncover a significant amount of coin, a sealed ceramic jar, two spell scrolls, several potions, and a handful of gems.
- Several methods were attempted to bring the Makrura to shore as they would fetch a high price, but the group is ultimately unsuccessful.
- Arriving back on land, the party accompanies Ga'an as he seeks out Mother Norn'sa. She can be found in the back room of JoJo's. Isilee sells the cursed fel blade from Ragefire Chasm to JoJo before entering Mother Norn'sa's room.
- Mother Norn'sa's room is cluttered and dimly lit. The room is decorated with dozens of pieces of driftwood.
  - Norn'sa sits in the center of the room, carving the driftwood with a Troll tusk. She tells Ga'an that he's been expected, and explains that everyone in the village has a piece of driftwood, which helps her interpret the spirits. She chides Ga'an for not visiting her before setting out from Sen'jin Village the first time.
- Norn'sa begins a reading for Ga'an, pulling out a brazier and a bag of carved bones. She holds Ga'an's driftwood over the fire and allows Ga'an to take it. He hears Bwonsamdi's voice echo in his mind as he does so.
  - Ga'an struggles at first to clear his mind, which Mother Norn'sa notes as she mutters her incantations. Ga'a'n finally lets go of his apprehensions and feels a warmth travel through his hands into his arms, chest, and head.
  - Light flashes from both their eyes and the room is plunged into darkness.
  - Everyone feels weightless, and is unable to see anything. Feelings of loneliness pervade the space and no sound exists.
- A blue green flame bursts from the brazier and shadows dance around the room. The drift wood floats on its own over the ghostly flames. Her voice now fills the room with renewed vigor.
  - The spirits tell her all. Coldness consumes Ga'an. A cold presence takes over the room, as if the party are all caught in a blizzard.
- Norn'sa speaks of a burning hatred for a single troll that has taken almost everything from Ga'an
  - The burning carvings coalesce into the eerie tribal mask of Zalazane. A low maniacal laughter begins to fill the room.
  - The party closes their eyes and reopens them to find the mask has disappeared. Now, the tent is filled with firelight and embers and smoke fill the air. There is no visible source of this, and shadows of fleeing trolls dance across the tent.
- A single tall silhouette is behind Mother Norn'sa. A single voice calls out, "Molla, where are you?"
  - The silhoute is attacked by a shadow, and is shot in the shoulder and tackled to the ground.
  - Norn'sa muses that hatred drives Ga'an, and he seeks power in order to achieve his vengeance. At what cost will this come?
- The flame begins to turn black and grey, and new carvings on the driftwood begin to glow.
  - The sigils float into the air and float into the air toward Ga'an, but he can't move or do anything. When he looks down, he sees dark shadowy chains reaching out of the ground to hold him in place. The symbols collide with his chest and all of his tattoos begin to glow with the same color, radiating even through the armor. An agreement he doesn't know the terms to, Norn'sa sees all of this.
- The flame shifts to a light blue color, and the sound and smell of the sea fills the air.
  - The destination is Darkspear Isles. It lies beneath the ocean. The light filtering through the canvas begins to darken as if going deeper and deeper into the ocean. Suddenly, hundreds of burning orange eyes with slit pupils can be seen on the canvas, a deep voice reverberates, "WATCHING". There is something ancient about the voice. The minions of this ancient evil now guard the island. A whirlpool and mist on the surface, and nothing to hide you below the sees.
  - Shadows will be the party's ally on this journey. That which they seek remains untouched, protected by the will of the Loa.
  - The shadowy troll silhouette of Bwonsamdi appears, and with it chains that stretch from Ga'an to his hands.
- Norn'sa warns that First Home is not a place of peace or safety. Those who travel there will be tested by the loa. The spirits hide survival or death from her visions.
  - The journey will be treacherous, and the party will have no experience with this enemy. The spirits don't even fully understand this evil, an evil older than Azeroth itself. The minions have pledged their allegiance to this darkness. Shadows and Caution will be their friend. Don't kick the nest, use stealth.
  - Should Ga'an fail, the village will be doomed. Should Ga'an succeed, that will not be the end of his trials. This will just be the first test.
- The fire shifts to a golden yellow color. The ocean air fades and is replaced with an arid intense heat. The silhouette of Bwonsamdi can still be seen, along with the endless deserts of Tanaris.
  - The Farraki trolls in the city of Zul Furak have been lead astray by an eldritch evil, Ueetay No Mueh'zala.
  - Blood begins to trickle from Norn'sa's nose, and the earth trembles. A silhouette much larger than Bwonsamdi appears.
  - Through the efforts of Bwonsamdi, the original keeper of souls has been almost erased.
- Ga'an asks of Norn'sa, should hesucceed, what will Bwonsamdi ask of him next?
  - The silhouette fades, but the eyes of Bwonsamdi remain just a second longer. A raspy menacing laugh echoes through the room, the voice of Bwonsamdi.
- The last time multiple people went to first home together was Vol'jin and Zalazane. Those who go to first home don't return the same people they were before they left.
  - Did the trials Zalazane underwent cause him to go mad and attack the trolls, or was it always his path?
  - Norn'sa pulls out Zalazane's driftwood, and says the spirits don't give absolutes. Fate and destiny are often guided but they aren't set in stone. The only absolutes are a beginning and an end.
  - Zalazane was given a choice at first home, and he chose the path that hurt many. Ga'an will have a choice at first home as well.
  - Our enemies are those who chose to follow evil, whether at first home or at Zul Furak.
- Norn'sa warns: "Don't be stupid Ga'an, beware the minions of the eldritch entity that lie beneath the waves. The sea witch and her ilk should not be disturbed lightly. Use caution and be wary of the mists and whirlpool that protect their kingdom."
- Norn'sa then turns to Adelade and says, "Mina misses you".
  - Adelaide immediately leaves the room
- Norn'sa tells Alyrin "the Emerald Dream awaits", says that Isilee is looking for a family, and that Juniper should check in on hers.
- With the ritual over, the party finds that Adelaide has completely left the building. They begin to search for her, and Isilee finds her at the beach, staring out at the tides.
  - The two have a heart to heart, and Adelaide confides that she broke when Mina died, and has felt that everything else that's followed is meaningless.

---

# Session #36
_Source DB: Session Notes_

# Session #36
# Full Notes
- The party awakens before dawn, exhausted and in a rush to set out. Ga'an visits the home of his family and says his goodbyes.
- After getting on board the ship, Ga'an is egged by Isilee
- The Gaytekeepër discuss Mother Norn'sa's reading and Alyrin realizes that she has some knowledge of an ancient evil in the deserts of Tanaris.
  - Alyrin states that she is a little worried about traveling out on the ocean because "there is some freaky stuff going on with the fish elves and stuff"
- Alyrin has some amount of knowledge of the Old Gods.
  - One is sealed in Tanaris, one is in the North, one is destroyed and one is lost and hasn’t been seen.
- More discussion is had after we find a small cove at the beach and Ga’an shares a bit more to the party about his goals and emotional state

---

# Session #37
_Source DB: Session Notes_

# Session #37
# Full Notes
- The party wakes up in the morning and sees the troll sailors preparing to depart.
- Juniper rolls around in the dirt. Isilee lies to Juniper that the plan was to jump overboard if we were attacked.
- The boat pushes off and the party is off again. However, where previously the boat stayed close to shore, now the shore is no longer in sight.
- Ga’an and Alyrin keep watch, but notice nothing throughout the day. Ga’an spends some time shaving copper dust.
- Eventually, the ship makes camp once more north of Tygard
- Ga’an with help from Juniper surveys the camp but finds nothing unexpected. The camp was marked with a the troll symbol for safe home.
- Isilee starts befriending Dentula and Tynoom while Ga'an makes a potion of healing.
- Juniper blows Alryrin up with a trap book. Oops.
- Upon arrival in Bladefist, the party goes to meet dockmaster Trapi Keenbol to charter a ship, who recommends that the GayteKeepërs speak with Captain Stormfang on dock three.
  - Trapi explains that charter rates are usually based on the captain. Stormfang has a crew of 12, so it could be up to 50 gold per day.
- The party meet with Captain Stormfang and reach an agreement to charter *The Jewel of the Horde* for up to four weeks. The price is a sum of 1200 GP, half of which must be paid upfront. The ship will set out at first light.
- The party decides to run some errands in Orgrimmar before setting out. A stop at Red Canyon Mining and Jewel Crafting proves particularly lucrative due to the use of moonlight calm on one of the two blood elf twins.

---

# Session #38
_Source DB: Session Notes_

# Session #38
# Full Notes
- More errands! Madam Marem, Rekul's Poisons, and a brothel [Adelaide will remember this.]
- Ga’an procures a Tome of Understanding which will boost his wisdom. He will be reading it for the foreseeable future.
- The party splits up to check out Dark Briar Lodge while Ga'an consults the Witch Doctors in the Valley of Spirits. Ga'an hears a strange laughter as he walks past the shrine of Bwomsamdi, but is pulled out of his trance by the apprentice witch doctor, Ur'kyo. He is then brought to meet the head witch doctor X'yera.
  - X'yeara tells Ga'an that when the Isles stood, they were scattered and disparate. They only unified when first the Alliance attacked, followed by the Seawitch. Ga'an is the first mortal that the Loa have taken personal interest in since Vol'jin. He is likely to be tested by Bwonsamdi personally.
  - The Loa are very powerful, and some are more forgiving than others. Some provide wisdom (Gonk) and how to be one with nature. Kragwa can be fickle but very loyal. Some are treacherous (Ganbala) the loa of serpents. Bwonsamdi is not as fickle as the Loa of serpents, but everything is transactional. The question must be “what will this mean for me?”
- X'yera further explains that the Trolls were once part of an empire called the Gurabashi. The remnants of this civilization can be found in the forests of Stranglethorn. They are not very friendly. The Farraki were once part of the Gurabashi but moved on and left.
  - The Zandalari came before the Gurabashi. They ruled all of Azeroth for a very long time before the Night Elves struck them down. During the time of this empire, there was a priest to a god of death who proved himself worthy of power and trust. The legends speak of this god of death - one who has been forgotten. One who craved endless sacrifices. This follower saw this, and after receiving his power, turned on this nameless god and seized power for himself.
    - This forgotten god has endless hunger and unmatched cruelty. It was said that a deal was struck between him and Bwonsamdi in order to seal him away for all of time. The book is damaged, much has been removed. Ga’an is hallucinating his name onto the page of the damaged book.
  - X'yera warns that If someone were to try to bring the old loa of death into this world, it would destroy everything.
- The Loa live many planes. Some live in the emerald dream, some in this world and some in the plane of death (Bwonsamdi). The Loa cannot travel freely, but some radical cultists have attempted to bring the nameless god, but this would mark doomsday for all mortal races.
- The Witch Doctors have only met one Farraki, who managed to flee before being sacrificed. Her name was Batam'si. She refused to speak to anyone about it. She stayed at the Valley of Spirits for a time, but departed years ago, heading south. She may have headed into the Barrens at some point.
- When X’yera was young, he underwent the trial of First Home himself. Even now he is uncertain what is real and what is an illusion. Reality is different there, a protected site where the Loa can almost freely move between. The whole party will be tested and potentially separated. They will never know if what they see is true, or a test. Not all are fit for First Home. Many are never ready and die in the trial, or stagnate and fail to push forward.
- Further information about the Loa:
  - Hireek the loa of the midnight sky or the loa of treachery can provide stealth and silence
  - Kragwa can provide strength
  - The loa golden eagle can provide health
  - Shengo can provide us with safe travels and clear skies
  - Shirvala can provide strength and protection in battle
  - Gonk can provide intelligence and the hunt.
- Back at the tavern, the party learns to play the card game "Call of the Banshee". Garuk, a young orc down on his luck, finally won and we were all happy for him.
- Adelaide sneaks out at night to acquire some "company". She is not as sneaky as she would like and the party notices her disappearance and flips their shit. There is a confrontation about it in the morning and a fair amount of tension in the party.

---

# Session #39
_Source DB: Session Notes_

# Session #39
# Full Notes
- In the morning, the party meet the first mate of the *Jewel,* a Tauren named Izha Strongwind. They pay the first half of the fee and the ship begins to set sail. Juniper has some awkward Tauren bonding but manages not to faint.
  - Izha tells everyone of the recent quillboar attacks in Mulgore, alongside the drought in the Barrens and Stone Talon. In addition, the Venture Company have been invading the area and set up a processing plant at Windshear Crag.
- Alyrin summons a frog using her hat. Ga’an tries to eat the frog, but it turns to dust.
- North Watch ships attack the *Jewel*, but fuck around and find out.
- Ga’an casts scorcher during the fight, and accidently ignites the ships gunpowder stores. This was not what he expected to happen.
- Alyrin is knocked unconscious, and then “healed” by the blood elf bard, Velarise. Luckily, she is stabilized by her necklace.
- The party investigates the scorched remnants of the North Watch ship, uncovering the following:
  - A wooden lock box lined with lead. Inside is a broken holy symbol, as well as a badly worn libram to the light, with pages ripped out and "lies" scratched over the text, as well as the phrase "the hour of twilight is at hand" and "In darkness, there are infinite paths"
  - A missive written to Lady Admiral Proudmoore referencing her "late husband" and "the traitorous Lady Jaina Proudmoore"
  - A small necklace with a gold pendant in the shape of an eye with a slit-pupil. The necklace itself does not possess any magical properties, but the person in possession of it hears a deep voice like in Mother Norn'sa's hut which warns, "WATCHING"
  - A diary of a Kul Tiran sailor chronicling his descent into madness over the course of his voyage. The diary notes that the crew was denied entry first into Silvermoon due to the Blood Elves joining the Horde, then into Gilneas. They were able to trade some goods at the dock but denied the ability to restock food or enter the city due to food shortages and fear of another outbreak of the undead plague. The city also is rumored to be swept up in a civil war and dealing with a dark curse in the countryside that twists people into "savage wolf men". They also learned in Stormwind that the country is wracked by civil war with the Defias Brotherhood. In addition, King Varian went missing en route on a diplomatic mission to Theramore, leaving the ten year old Anduin as King and Bolvar Fordragon as his Regent Lord. The diary begins to contains phrases such as "the hour of twilight", "infinite possibilities", "the Black Empire", and "may the shadow of C'thun guide me". The pages also contain an illustration of
    - An octopus-shaped silhouette with a variety of sharp spines covering its immense body and tentacles.
    - An immense Ziggurat and hellish landscape dotted with obelisks and structures overlooked by a giant octopus-like creature with a giant eye above its head.
    - An immense ancient city with a sealed gate.
  - The sailor's diary describes being plagued by whispers of "watching" and "infinite possibilites". A visit to the Night Elven tree of Teldrassil yielded a nightmare in which the tree's reflection in the still water grew unnatural spike-like growths on the trunk that glowed a crimson red. Dark energy poured out from its branches and gave the tree an ominous aura. Monsters and abominations of flesh, tentacles, eyes, and teeth crawled from the holes and crevices littering its surface. A familiar voice rang out: "New Beginning". The sailor soon begins to talk of the need to go to the desert to "break him out" from "behind that accursed wall". He prays "may the shadow of C'thun guide me" and writes "C'thun how I long witness your awesome might".
- Back on the *Jewel*, Captain Stormfang is understandably PO'd about the damage to his ship but the party compensates him well for the damages to smooth things over.
- Adelaide writes a missive to Jes'rimmon detailing the findings and Alyrin sends Scintilla to deliver the message.

---

# Session #4
_Source DB: Session Notes_

# Session #4
# Full Notes
- The group searched Baron Longshore's tent and found a map of the Barrens, a manifest of future shipments "signed" by Gazlowe, and communications referring to the pirates "contact" (Retick Fiztorque) giving them information on an upcoming shipment.
- The group make it out of the pirate camp and set off to reunite Gilthares Firebough with his cousin, Captain Brightsun, who had previously hired Isilee and Alyrin to retrieve Gilthares.
- The group discovers that Retick has been working for Longshore for several years

---

# Session #40
_Source DB: Session Notes_

# Session #40
# Full Notes
- The party unpacks the revelations of the last session further. Alyrin/Adelaide recall that the "Hour of Twilight" refers to an armageddon whereby all life is snuffed out in the entire great beyond in an instant.
- Velarise comes to apologize to Alyrin for almost killing her. The Gatekeepërs learn that she is 85 years old (relatively young for a Blood/High Elf, but older than Adelaide). She comes from Fairbreeze, a farming community in Western Quel'thalas. Adelaide is very snobby about this and Velarise leaves, dejected.
- Isilee opens up a bit more about her own life story. She knew Pietro as a child in Lordaeron and was partners-in-petty-crime with him. When her mother grew ill, her father took her to Silvermoon, "the only good thing he ever did" for her.
  - She is cagey in her answer about how she met Pietro again as an adult and where she was after being in Silvermoon.
- A'thian shows the party a map of Darkspear, identifying First Home for the group. The party decides to stop at the Temple of the Loa and Dazduga Shrine to make the proper tribute to the Loa before entering first home.
- As the ship sails nearer to the isles, Ga’an is kept awake that night with apprehension. What will Darkspear look like? What will have changed? Ga’an remembers hunts and adventures around the island, rituals celebrating Gonk and other Loa.
- The entire ship is awakened in the night by an attack of Naga. One of the crew dies in the attack, and Stormfang grows furious when he overhears talk of occult symbols brought on board by the team. Alyrin's Moonlight Calm saves the day for the party to not be thrown overboard.
- The party debate tossing the lead-lined box overboard but decide against it.
- In the morning, the ship sails into a heavy mist that is magical and unable to be dispelled by Adelaide.
- Ga'an's tattoos glow purple, a beacon pointing in the direction of First Home.
- The Gaytekeepërs have a Tusk Love book club/cuddle puddle to pass the time.
- Fish attack!

---

# Session #41
_Source DB: Session Notes_

# Session #41
# Full Notes
- Cade and I both have shit notes for this oops
- More naga attack! The party defeats them but!
- Whirlpool!
- Izha and Stormfang manage to successfully maneuver the ship onto a rock to stop the descent into the whirlpool.
- Ga'an's tattoos seem to point directly to the center of the whirlpool