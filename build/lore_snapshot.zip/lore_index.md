# Lore Snapshot Index

List of pages and alias variants.

## Adelaide Dawntreader
- Database: **Characters**
- Page ID: `2992fb8c-325a-808b-af6f-c6de5be63b99`
- Aliases: Adelaide Dawntreader, adelaide dawntreader

## Alyrin
- Database: **Characters**
- Page ID: `2992fb8c-325a-8032-8a5b-c5195eeefa62`
- Aliases: Alyrin, alyrin

## Ga’an
- Database: **Characters**
- Page ID: `2992fb8c-325a-80d8-8b35-d79caa92f127`
- Aliases: Ga'an, Gaan, Ga’an, ga'an, gaan, ga’an

## Isilee Shorestrider
- Database: **Characters**
- Page ID: `2992fb8c-325a-80d3-820a-c9c1a7a391e1`
- Aliases: Isilee Shorestrider, isilee shorestrider

## Juniper
- Database: **Characters**
- Page ID: `2992fb8c-325a-80d1-bf5b-eff54b35c954`
- Aliases: Juniper, juniper

## Party Goals Tracker
- Database: **Party Goals**
- Page ID: `2992fb8c325a80efbb32edb10a21c3ba`
- Aliases: Party Goals Tracker, party goals tracker

## Session #10
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8070-9826-e6f9231d9438`
- Aliases: Session #10, session #10

## Session #11
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-801b-946e-e4c218764b6f`
- Aliases: Session #11, session #11

## Session #12
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80f5-8f0a-f8fc5f469fcb`
- Aliases: Session #12, session #12

## Session #13
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-807f-81bf-c327ceac44ea`
- Aliases: Session #13, session #13

## Session #14
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80a5-a4c6-d55adc291167`
- Aliases: Session #14, session #14

## Session #15
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80a9-b62c-dc4d54c613d1`
- Aliases: Session #15, session #15

## Session #16
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8079-9eae-f09936321678`
- Aliases: Session #16, session #16

## Session #17
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80d6-ba5b-c27fef8042e5`
- Aliases: Session #17, session #17

## Session #18
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80bc-a947-cd0be4160682`
- Aliases: Session #18, session #18

## Session #19
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80bb-bc9b-d6148c9d80c7`
- Aliases: Session #19, session #19

## Session #1a
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-806a-ac59-dccc2905febc`
- Aliases: Session #1a, session #1a

## Session #1b
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8059-bde0-e274c7a80503`
- Aliases: Session #1b, session #1b

## Session #2
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8026-bde2-d2719281b9b1`
- Aliases: Session #2, session #2

## Session #20
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8056-ae23-d01991858d6e`
- Aliases: Session #20, session #20

## Session #21
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80be-af23-dc49e30f8aaa`
- Aliases: Session #21, session #21

## Session #22
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-804c-9ca6-d55effb3962e`
- Aliases: Session #22, session #22

## Session #23
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8068-bbed-ccbf8bbe47a6`
- Aliases: Session #23, session #23

## Session #24
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-802b-8297-c6ac40ac146e`
- Aliases: Session #24, session #24

## Session #25
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80b2-b995-c956e1ec92a3`
- Aliases: Session #25, session #25

## Session #26
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8023-a2da-c3658373a829`
- Aliases: Session #26, session #26

## Session #27
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80aa-9c61-d539229df49f`
- Aliases: Session #27, session #27

## Session #28
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8001-8d09-f8bee019245a`
- Aliases: Session #28, session #28

## Session #29
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8095-9000-c6dce479f57e`
- Aliases: Session #29, session #29

## Session #3
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-804a-980f-d330b6c0ae6e`
- Aliases: Session #3, session #3

## Session #30
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80dc-b413-de622fa105ac`
- Aliases: Session #30, session #30

## Session #31
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-803a-926a-fe30dc3a5ef9`
- Aliases: Session #31, session #31

## Session #4
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-804f-9a67-e61cbc856bac`
- Aliases: Session #4, session #4

## Session #5
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-805e-844f-d58529c8bc1d`
- Aliases: Session #5, session #5

## Session #6
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8010-8e39-d001259a622e`
- Aliases: Session #6, session #6

## Session #7
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8086-91de-c8b355715b5c`
- Aliases: Session #7, session #7

## Session #8
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80cb-975b-fff81bf129ff`
- Aliases: Session #8, session #8

## Session #9
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8045-922e-d0c23c95237a`
- Aliases: Session #9, session #9
