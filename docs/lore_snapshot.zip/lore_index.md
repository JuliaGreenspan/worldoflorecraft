# Lore Snapshot Index

List of pages and alias variants.

## Adelaide Dawntreader
- Database: **Characters**
- Page ID: `2992fb8c-325a-808b-af6f-c6de5be63b99`
- Aliases: Adelaide Dawntreader, adelaide dawntreader

## Alyrin
- Database: **Characters**
- Page ID: `2992fb8c-325a-8032-8a5b-c5195eeefa62`
- Aliases: Alyrin, alyrin

## Ga’an
- Database: **Characters**
- Page ID: `2992fb8c-325a-80d8-8b35-d79caa92f127`
- Aliases: Ga'an, Gaan, Ga’an, ga'an, gaan, ga’an

## Isilee Shorestrider
- Database: **Characters**
- Page ID: `2992fb8c-325a-80d3-820a-c9c1a7a391e1`
- Aliases: Isilee Shorestrider, isilee shorestrider

## Juniper
- Database: **Characters**
- Page ID: `2992fb8c-325a-80d1-bf5b-eff54b35c954`
- Aliases: Juniper, juniper

## Party Goals Tracker
- Database: **Party Goals**
- Page ID: `2992fb8c325a80efbb32edb10a21c3ba`
- Aliases: Party Goals Tracker, party goals tracker

## Session #10
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8070-9826-e6f9231d9438`
- Aliases: Session #10, session #10

## Session #11
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-801b-946e-e4c218764b6f`
- Aliases: Session #11, session #11

## Session #12
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80f5-8f0a-f8fc5f469fcb`
- Aliases: Session #12, session #12

## Session #13
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-807f-81bf-c327ceac44ea`
- Aliases: Session #13, session #13

## Session #14
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80a5-a4c6-d55adc291167`
- Aliases: Session #14, session #14

## Session #15
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80a9-b62c-dc4d54c613d1`
- Aliases: Session #15, session #15

## Session #16
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8079-9eae-f09936321678`
- Aliases: Session #16, session #16

## Session #17
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80d6-ba5b-c27fef8042e5`
- Aliases: Session #17, session #17

## Session #18
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80bc-a947-cd0be4160682`
- Aliases: Session #18, session #18

## Session #19
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80bb-bc9b-d6148c9d80c7`
- Aliases: Session #19, session #19

## Session #1a
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-806a-ac59-dccc2905febc`
- Aliases: Session #1a, session #1a

## Session #1b
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8059-bde0-e274c7a80503`
- Aliases: Session #1b, session #1b

## Session #2
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8026-bde2-d2719281b9b1`
- Aliases: Session #2, session #2

## Session #20
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8056-ae23-d01991858d6e`
- Aliases: Session #20, session #20

## Session #21
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80be-af23-dc49e30f8aaa`
- Aliases: Session #21, session #21

## Session #22
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-804c-9ca6-d55effb3962e`
- Aliases: Session #22, session #22

## Session #23
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8068-bbed-ccbf8bbe47a6`
- Aliases: Session #23, session #23

## Session #24
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-802b-8297-c6ac40ac146e`
- Aliases: Session #24, session #24

## Session #25
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80b2-b995-c956e1ec92a3`
- Aliases: Session #25, session #25

## Session #26
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8023-a2da-c3658373a829`
- Aliases: Session #26, session #26

## Session #27
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80aa-9c61-d539229df49f`
- Aliases: Session #27, session #27

## Session #28
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8001-8d09-f8bee019245a`
- Aliases: Session #28, session #28

## Session #29
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8095-9000-c6dce479f57e`
- Aliases: Session #29, session #29

## Session #3
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-804a-980f-d330b6c0ae6e`
- Aliases: Session #3, session #3

## Session #30
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80dc-b413-de622fa105ac`
- Aliases: Session #30, session #30

## Session #31
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-803a-926a-fe30dc3a5ef9`
- Aliases: Session #31, session #31

## Session #32
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80a8-826b-e3f8a48b2abb`
- Aliases: Session #32, session #32

## Session #33
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8019-833f-f1e963296203`
- Aliases: Session #33, session #33

## Session #34
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8064-b0fc-d171ffb9c5ca`
- Aliases: Session #34, session #34

## Session #35
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80ef-a4f5-eba769fccbca`
- Aliases: Session #35, session #35

## Session #36
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80c9-b9c9-fee47eae4b2a`
- Aliases: Session #36, session #36

## Session #37
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80e3-aa95-eb278ee8750e`
- Aliases: Session #37, session #37

## Session #38
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8006-85f3-d31fbd9563cd`
- Aliases: Session #38, session #38

## Session #39
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8023-bec1-dced0264a708`
- Aliases: Session #39, session #39

## Session #4
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-804f-9a67-e61cbc856bac`
- Aliases: Session #4, session #4

## Session #40
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8002-8652-ef7021e0f5da`
- Aliases: Session #40, session #40

## Session #41
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-800e-a7fb-cb316d6ee37b`
- Aliases: Session #41, session #41

## Session #42
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80bb-94ce-decfe9ec62b0`
- Aliases: Session #42, session #42

## Session #43
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8064-b859-c2cc442ab837`
- Aliases: Session #43, session #43

## Session #44
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8063-8f12-dc03c626d5ac`
- Aliases: Session #44, session #44

## Session #45
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8042-b504-e17215f69a88`
- Aliases: Session #45, session #45

## Session #46
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8015-a66a-e593b760e9bf`
- Aliases: Session #46, session #46

## Session #47
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-802c-9461-d2f10888d9ec`
- Aliases: Session #47, session #47

## Session #48
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80c1-86f1-e0c289299bce`
- Aliases: Session #48, session #48

## Session #49
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8016-804d-c20abaa5aae2`
- Aliases: Session #49, session #49

## Session #5
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-805e-844f-d58529c8bc1d`
- Aliases: Session #5, session #5

## Session #50
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80c3-b96e-d6ae15604a0b`
- Aliases: Session #50, session #50

## Session #51
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80fe-9008-e41c240016da`
- Aliases: Session #51, session #51

## Session #52
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80da-b5b2-ecfecfbcb57c`
- Aliases: Session #52, session #52

## Session #53
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8059-b675-d4396e95207a`
- Aliases: Session #53, session #53

## Session #54
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8064-97ea-d78bab236190`
- Aliases: Session #54, session #54

## Session #55
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80f2-95ae-fc164efbe2e2`
- Aliases: Session #55, session #55

## Session #56
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8011-a5db-eaf2b8a85cde`
- Aliases: Session #56, session #56

## Session #57
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80fa-8add-c90b37b4b23f`
- Aliases: Session #57, session #57

## Session #58
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-803c-a5b4-eef8e82ebeb2`
- Aliases: Session #58, session #58

## Session #59
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-801e-b7ed-f9b082ac34dc`
- Aliases: Session #59, session #59

## Session #6
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8010-8e39-d001259a622e`
- Aliases: Session #6, session #6

## Session #60
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80de-a122-d6aefad39aa1`
- Aliases: Session #60, session #60

## Session #61
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8076-ba47-ec811d35f325`
- Aliases: Session #61, session #61

## Session #62
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-8057-8777-ef69e327690a`
- Aliases: Session #62, session #62

## Session #63
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80c7-a2fe-e1da5bae4b3d`
- Aliases: Session #63, session #63

## Session #64
- Database: **Session Notes**
- Page ID: `29a2fb8c-325a-80da-a580-c2e2377d0b5d`
- Aliases: Session #64, session #64

## Session #7
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8086-91de-c8b355715b5c`
- Aliases: Session #7, session #7

## Session #8
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-80cb-975b-fff81bf129ff`
- Aliases: Session #8, session #8

## Session #9
- Database: **Session Notes**
- Page ID: `2992fb8c-325a-8045-922e-d0c23c95237a`
- Aliases: Session #9, session #9
